package br.com.alura.adopet.api.dto;

public record SolictacaoAdocaoDto(Long idPet, Long idTutor, String motivo) {
}
