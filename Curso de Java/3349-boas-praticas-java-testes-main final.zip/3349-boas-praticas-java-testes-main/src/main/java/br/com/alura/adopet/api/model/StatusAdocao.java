package br.com.alura.adopet.api.model;

public enum StatusAdocao {

    AGUARDANDO_AVALIACAO,
    APROVADO,
    REPROVADO;

}
